﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AppSuper
{
   class Suelto : Producto
    {

        private float medida;

        public Suelto() : base()
        {
            medida = 0;
        }
        public float Medida
        {
            get { return medida; }
            set { medida = value; }
        }

        public Suelto(int c, string m, double p, int t, float medida) : base(c, m, p, t)
        {
            this.medida = medida;
        }
        public override double GetPrecio()
        {
            return this.medida * this.pPreUnitario;
        }
        public override string ToString()
        {
            return
                "Producto " + base.ToString() +
                "Medida " + medida +
                "Precio por producto suelto " + GetPrecio();

        }
















    }
}
