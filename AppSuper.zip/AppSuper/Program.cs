﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AppSuper
{
    internal class Program
    {
        static void Main(string[] args)
        {

            Suelto s1 = new Suelto(1234, "Gomitas", 200, 1, 50);
            Suelto s2 = new Suelto(1908, "Almendras Con Chocolate", 300, 1, 100);
            Pack p1 = new Pack(6793, "Fideos", 600, 2, 1);
            Pack p2 = new Pack(7484, "Leche Serenisima", 300, 2, 4);

            Supermercado SuperMami = new Supermercado();

            SuperMami.AgregarProducto(p1);
            SuperMami.AgregarProducto(p2);
            SuperMami.AgregarProducto(s1);
            SuperMami.AgregarProducto(s2);

            //  calcular la cantidad de productos sueltos
            Console.WriteLine("Cantidad de sueltos ");
            Console.WriteLine(SuperMami.CantSuelto());

            //  la cantidad de productos en packs
            Console.WriteLine("Cantidad de Packs");
            Console.WriteLine(SuperMami.cantPack());

            //el precio promedio de productos sueltos
            Console.WriteLine("Precio Promedio de sueltos");
            Console.WriteLine(SuperMami.PromedioSuelto());

            //el porcentaje de packs
            Console.WriteLine("Porcentaje de packs");
            Console.WriteLine(SuperMami.PorcentajePack());

            //  el código y marca del pack más costoso.
            Console.WriteLine("Codigo y marca del pack mas costoso");
            Console.WriteLine(SuperMami.PackMasCostoso());

            






            Console.ReadLine();

                  




















        }
    }
}
