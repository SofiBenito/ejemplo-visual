﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AppSuper
{
    class Supermercado
    {

        private Producto[] productos;
        private int ultimoProducto;
        private string nombreSuper;

        public Supermercado (string nombreSuper, int cantProducto)
        {
            this.nombreSuper = nombreSuper;
            this.productos = new Producto[cantProducto];
            ultimoProducto = 0;
        }

        public Supermercado()
        {
            nombreSuper =string.Empty;
            productos = new Producto[10];
            ultimoProducto=0;
        }
       

        public string pNombreSuper
        {
            get { return nombreSuper; } 
        }
        
        public bool AgregarProducto(Producto unProducto)
        {
            if (ultimoProducto< productos.Length)
            {
                productos[ultimoProducto] = unProducto;
                ultimoProducto++;
                return true;
            }
            else
            {
                return false;
            }
        }
      //  calcular la cantidad de productos sueltos
        public int CantSuelto()
        {
            int contSuelto=0;
            foreach (Producto suelto in productos)
            {
                if (suelto !=null && suelto.pTipo==1)
                {
                    contSuelto++;
                }
            }
            return contSuelto;
        }
      //  la cantidad de productos en packs
        public int cantPack()
        {
            int cantProducto =0;
            foreach(Producto pack in productos)
            {
                if (pack !=null && pack.pTipo==2)
                {
                    cantProducto++;
                }

            }
            return cantProducto;
        }
        //el precio promedio de productos sueltos

        public double PromedioSuelto()
        {
            double promedioSuelto=0;
            double acumulador=0;

            foreach(Producto suelto in productos)
            {
                if (suelto !=null && suelto.pTipo==1)
                {
                    acumulador += acumulador + suelto.GetPrecio(); 
                }

            }
            promedioSuelto=acumulador/ CantSuelto();
            return promedioSuelto;

        }

        //el porcentaje de packs

        public double PorcentajePack()
        {
            double porcentajePack=0;
            porcentajePack = cantPack() * 100 / ultimoProducto;
            return porcentajePack;
        }
        //  el código y marca del pack más costoso.

        public string PackMasCostoso()
        {
            Producto PackMayor = productos[0];

            for (int i = 0; i < ultimoProducto; i++)
            {
                if (productos[i] != null && productos[i].pTipo == 2 && productos[i].pPreUnitario > PackMayor.pPreUnitario)
                {
                    PackMayor = productos[i];
                   

                }
            }
            return "El pack con el codigo   " + PackMayor.pCodigo + "  Con la marca   " + 
                PackMayor.pMarca + "  Con El Precio   " + PackMayor.pPreUnitario +  "Es el pack Mas Costoso" ;

        }

      





    }
}
