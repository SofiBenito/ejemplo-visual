﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AppSuper
{
   class Pack : Producto
    {

        private int cantidad;

        public Pack() : base()
        {
            cantidad = 0;
        }

        public int pCantidad
        {
            get { return cantidad; }
            set { cantidad = value; }
        }
        public Pack(int c, string m, double p, int t, int cantidad) : base(c, m, p, t)
        {
            this.cantidad = cantidad;
        }

        public override double GetPrecio()
        {
            return this.cantidad * this.pPreUnitario;
        }

        public override string ToString()
        {
            return
                "Producto " + base.ToString() +
                "Cantidad " + cantidad +
                "Precio por la cantidad " + GetPrecio();
        }


















    }
}
