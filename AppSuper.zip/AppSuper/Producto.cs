﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AppSuper
{
    abstract class Producto
    {

        private int codigo;
        private string marca;
        private double preUnitario;
        private int tipo;

        public Producto()
        {
            codigo = 0;
            marca = string.Empty;
            preUnitario = 0;
            tipo = 0;
        }

        public int pCodigo
        {
            get { return codigo; }
            set { codigo = value; }
        }
        public string pMarca
        {
            get { return marca; }
            set { marca = value; }
        }

        public double pPreUnitario
        {
            get { return preUnitario; }
            set { preUnitario = value; }
        }
        public int pTipo
        {
            get { return tipo; }
            set
            {
                if (value ==1 || value ==2)
                {
                    tipo = value;
                }
            }


        }
        public Producto(int codigo, string marca, double preUnitario, int tipo)
        {
            this.codigo = codigo;
            this.marca = marca;
            this.preUnitario = preUnitario;
            this.tipo = tipo;
        }

        public abstract double GetPrecio();

        public override string ToString()
        {
            return
                "Codigo de producto " + codigo +
                "Marca " + marca +
                "Precio " + preUnitario +
                "Tipo " + tipo;
        }




















    }
}
